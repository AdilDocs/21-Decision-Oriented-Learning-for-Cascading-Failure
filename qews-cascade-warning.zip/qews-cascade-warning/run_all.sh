#!/bin/bash
# Reproduces every table and figure of the paper. Run from the repository root:  bash run_all.sh
# Requires data/time_series_60min_singleindex.csv (OPSD, see README). Total runtime on 2 cores: roughly 8-12 hours,
# dominated by Monte Carlo label generation. Intermediate files go to work/, final tables and figures to work/results/.
set -e
ROOT=$(cd "$(dirname "$0")" && pwd); mkdir -p "$ROOT/work"; cd "$ROOT/work"
S=../src

echo "== 0. IEEE case data";                       python $S/extract_cases.py

echo "== 1. Ground truth + features (Sec. IV)"
Q_SECURE=0.9 K_MARGIN=1.10 python $S/pipeline.py case39          # all hours, 2015 + 2016
Q_SECURE=0.6 K_MARGIN=1.05 python $S/pipeline.py case118
Q_SECURE=0.9 K_MARGIN=1.10 python $S/pipeline.py case300 2500    # 2500 random hours per year

echo "== 2. Comparison (Table III, Fig. 2)"
python $S/evaluate.py case39
python $S/evaluate.py case118
python $S/evaluate.py case300 2500

echo "== 3. Sensitivity, IEEE 39-bus (Fig. 3)"
export Q_SECURE=0.9 K_MARGIN=1.10
for spec in "_full_K0 0 0.6" "_full_K12 12.5 0.6" "_full_K50 50 0.6" "_full_M0 25 0.0" "_full_M3 25 0.3" "_full_M9 25 0.9"; do
  set -- $spec
  TAG=$1 STORM_K=$2 MAINT_P=$3 python $S/pipeline.py case39
  TAG=$1 python $S/evaluate.py case39
done
for f in 0.02 0.05 0.10; do                        # forecast error changes features only -> reuse ground truth
  ln -sf case39_gt2.pkl case39_full_f${f}_gt2.pkl
  TAG=_full_f$f FERR=$f python $S/pipeline.py case39
  TAG=_full_f$f python $S/evaluate.py case39
done
unset Q_SECURE K_MARGIN

echo "== 4. Convergence (Fig. 4)"
python $S/conv.py case118
python $S/conv_mc_annual.py

echo "== 5. Decision analysis (Table V) and timing (Table IV)"
mkdir -p results
python $S/decision_analysis.py
python $S/timing.py case39; python $S/timing.py case118; python $S/timing.py case300 2500

echo "== 6. Tables and figures"
python $S/make_results.py
python $S/make_fig1.py
echo "Done: see work/results/ and paper_figures/"
