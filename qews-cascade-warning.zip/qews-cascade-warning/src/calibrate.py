"""Optional: line-limit calibration (Table II). Estimates the no-action cascade loss (% of energy) on 250 random
training hours for a given (q, k). Usage: python ../src/calibrate.py case39 0.9 1.10
The paper uses (0.9, 1.10) for 39- and 300-bus and (0.6, 1.05) for 118-bus (target: about 1% of energy)."""
import os, sys, importlib, numpy as np
case, q, k = sys.argv[1], sys.argv[2], sys.argv[3]
tmp = f"{case}_lim_calib_q{q}_k{k}.npy"
os.environ["Q_SECURE"], os.environ["K_MARGIN"] = q, k
had = os.path.exists(f"{case}_lim.npy")
if had: os.rename(f"{case}_lim.npy", f"{case}_lim.keep")
try:
    sys.argv = ["pipeline.py", case]
    import pipeline as p
    p.OPTIONS = [(-1, 0.0)]
    ts = np.random.default_rng(3).choice(8760, 250 if case != "case300" else 80, replace=False)
    el = np.array([p.gt_hour((2015, int(t)))[1][0][0] for t in ts])
    load = np.mean([p.PR[2015]["load"][t] @ np.maximum(p.S["PD0"], 0) for t in ts])
    print(f"{case} q={q} k={k}: risky hours {np.mean(el > 0):.0%}, no-action loss {100 * el.mean() / load:.2f}% of energy")
finally:
    if os.path.exists(f"{case}_lim.npy"): os.rename(f"{case}_lim.npy", tmp)
    if had: os.rename(f"{case}_lim.keep", f"{case}_lim.npy")
