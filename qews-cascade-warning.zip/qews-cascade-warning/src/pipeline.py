"""Shared pipeline for IEEE 39 / 118 / 300.   usage: python pipeline.py case118 [n_hours_per_year]
Stage 1 ground truth (actual data): EL_s(t) = Lam(t) * E_{l ~ pi(t)}[load lost | initiating outage l], s in LEVELS
Stage 2 day-ahead features (forecast data)
Results are cached in <case>_*.pkl; evaluation is in evaluate_all.py.
"""
import sys, os, pickle, numpy as np
from multiprocessing import Pool
import gridN as g

CASE = sys.argv[1] if len(sys.argv) > 1 else "case118"
NH = int(sys.argv[2]) if len(sys.argv) > 2 else 0          # 0 = all hours
YEARS = (2015, 2016); N_INIT = 30
# decision options: no action, or shed 2/4/8% of the forecast load of ONE area (area-targeted preventive shedding)
OPTIONS = [(-1, 0.0)] + [(a, f) for a in range(4) for f in (0.02, 0.04, 0.08)]
LEVELS = OPTIONS
STORM_K = float(os.environ.get("STORM_K", "25.0")); DERATE = 0.12; MAINT_P = float(os.environ.get("MAINT_P", "0.6"))
TAG = os.environ.get("TAG", "")
S = g.load_case(CASE)
PR = {y: g.profiles(y) for y in YEARS}
LIMF = f"{CASE}_lim.npy"
Q_SECURE = float(os.environ.get("Q_SECURE", "0.6"))           # grid is N-1 secure up to this load quantile
K_MARGIN = float(os.environ.get("K_MARGIN", "1.05"))
if not os.path.exists(LIMF): np.save(LIMF, g.make_limits(PR[2015], q=Q_SECURE, k=K_MARGIN))
LIM = np.load(LIMF)


def conditions(y):
    pr = PR[y]; T = len(pr["sys"]); la = S["BUS_AREA"][S["F"]]
    lam = 1 + STORM_K * np.maximum(0, (pr["W"][:, la] - 0.6) / 0.4) ** 2
    lim_t = LIM[None, :] * (1 - DERATE * pr["S"][:, la])
    rng = np.random.default_rng(y); alive0 = np.ones((T, S["NL"])); maint = np.full(T, -1)
    for w in range(T // 168 + 1):
        if rng.random() < MAINT_P:
            l = rng.choice(S["INIT"]); alive0[w * 168:(w + 1) * 168, l] = 0; maint[w * 168:(w + 1) * 168] = l
    lam = lam * alive0; lam[:, S["BRIDGES"]] = 0
    Lam = lam.sum(1) / len(S["INIT"]); pi = lam / lam.sum(1, keepdims=True)
    return dict(lim=lim_t, alive0=alive0, maint=maint, pi=pi, Lam=Lam)

C = {y: conditions(y) for y in YEARS}
HOURS = {y: (np.arange(len(PR[y]["sys"])) if NH == 0 else
             np.sort(np.random.default_rng(y + 7).choice(len(PR[y]["sys"]), NH, replace=False))) for y in YEARS}


def cascade(P, lim, init, rng, alive0, max_gen=15):
    alive = alive0.copy(); alive[init] = 0; gens = [[int(init)]]
    for _ in range(max_gen):
        f, lost = g.dcflow(P, alive)
        trip = (rng.random(S["NL"]) < g.trip_prob(np.abs(f) / lim * alive)) & (alive > 0)
        if not trip.any(): return lost, gens
        alive[trip] = 0; gens.append(list(np.where(trip)[0]))
    return g.dcflow(P, alive)[1], gens


_H = {}
def ptdf_cached(y, t):
    key = (y, int(C[y]["maint"][t]))
    if key not in _H: _H[key] = g.ptdf(C[y]["alive0"][t])
    return _H[key]


def shed_vec(pr, t, a, s):
    if a < 0: return None
    return s * np.maximum(S["PD0"], 0) * pr["load_f"][t] * (S["BUS_AREA"] == a)


def gt_hour(args):
    y, t = args; pr, c = PR[y], C[y]; out, recs = [], []
    H = ptdf_cached(y, t)
    rng0 = np.random.default_rng(y * 1000003 + t)
    inits = rng0.choice(S["NL"], N_INIT, p=c["pi"][t]); seeds = rng0.integers(0, 2**31, N_INIT)
    for (a, s) in OPTIONS:
        P, pd_ = g.injections(pr["load"][t], pr["wind"][t], pr["solar"][t], shed=shed_vec(pr, t, a, s))
        F1, f0 = g.lodf_n1(P, c["alive0"][t], H)
        if not ((g.trip_prob(np.abs(F1) / c["lim"][t]) > 0).any() or (g.trip_prob(np.abs(f0) / c["lim"][t]) > 0).any()):
            out.append((0.0, 0.0)); continue
        L = []
        for i, sd in zip(inits, seeds):
            lo, gens = cascade(P, c["lim"][t], i, np.random.default_rng(sd), c["alive0"][t]); L.append(lo)
            if a < 0 and y == 2015: recs.append(gens)
        L = np.array(L); tot = np.maximum(pd_, 0).sum()
        out.append((c["Lam"][t] * L.mean(), min(1.0, c["Lam"][t] * (L > 0.05 * tot).mean())))
    return (y, t), out, recs


FERR = float(os.environ.get("FERR", "0"))     # extra day-ahead forecast error (std, relative) on the TEST year


def feat_hour(args):
    y, t = args; pr, c = PR[y], C[y]
    lf, wi, so = pr["load_f"][t], pr["wind"][t], pr["solar"][t]
    if FERR > 0 and y == 2016:
        r = np.random.default_rng(10007 + t)
        lf = lf * (1 + FERR * r.standard_normal(4))[S["BUS_AREA"]]
        wi = np.clip(wi * (1 + 3 * FERR * r.standard_normal(len(wi))), 0, 1)
        so = np.clip(so * (1 + 2 * FERR * r.standard_normal(len(so))), 0, 1)
    P, _ = g.injections(lf, wi, so)
    F1, f0 = g.lodf_n1(P, c["alive0"][t], ptdf_cached(y, t))
    base = np.abs(f0) / c["lim"][t]; n1 = (np.abs(F1) / c["lim"][t]).max(0)
    area = [lf[S["BUS_AREA"] == a][0] for a in range(4)]
    m1 = (c["pi"][t][S["INIT"]] @ g.trip_prob(np.abs(F1) / c["lim"][t]))           # weather-weighted first-step trip prob
    la = S["BUS_AREA"][S["F"]]
    amax = [n1[la == k].max() if (la == k).any() else 0 for k in range(4)]
    return (y, t), dict(x=np.r_[area, wi, so, pr["W"][t], pr["S"][t], float(c["maint"][t] >= 0),
                                base.max(), n1.max(), base, n1, amax], base=base, m1=m1, Lam=c["Lam"][t], amax=np.array(amax))


if __name__ == "__main__":
    jobs = [(y, int(t)) for y in YEARS for t in HOURS[y]]
    if not os.path.exists(f"{CASE}{TAG}_gt2.pkl"):
        with Pool(2) as p: R = p.map(gt_hour, jobs, chunksize=25)
        pickle.dump(dict(GT={k: v for k, v, _ in R}, RECS=[r for _, _, rs in R for r in rs]), open(f"{CASE}{TAG}_gt2.pkl", "wb"))
        print(CASE, "ground truth done", flush=True)
    if not os.path.exists(f"{CASE}{TAG}_feat2.pkl"):
        with Pool(2) as p: FT = dict(p.map(feat_hour, jobs, chunksize=50))
        pickle.dump(FT, open(f"{CASE}{TAG}_feat2.pkl", "wb")); print(CASE, "features done", flush=True)
