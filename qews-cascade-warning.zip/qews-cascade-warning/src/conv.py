"""Convergence analysis (IEEE 118-bus, full data):
 (a) Monte Carlo ground truth: relative std. error of the hourly blackout estimate vs number of sampled initiating outages
 (b) LightGBM decision model: training / validation loss vs boosting iterations
 (c) Decision quality vs amount of training data (1, 2, 4, 8 months of 2015)
"""
import os, sys, pickle, numpy as np, pandas as pd, lightgbm as lgb, warnings
warnings.filterwarnings("ignore")
CASE = sys.argv[1] if len(sys.argv) > 1 else "case118"
sys.argv = ["pipeline.py", CASE]
import pipeline as p, gridN as g
os.environ["TAG"] = ""
import importlib

# ---------- (a) Monte Carlo convergence ----------
D = pickle.load(open(f"{CASE}_gt2.pkl", "rb"))
risky = [t for t in range(8760) if D["GT"][(2015, t)][0][0] > 0]
hrs = np.random.default_rng(0).choice(risky, 25, replace=False)
rows = []
for N in [5, 10, 20, 30, 60, 120]:
    rel = []
    for t in hrs:
        pr, c = p.PR[2015], p.C[2015]
        P, pd_ = g.injections(pr["load"][t], pr["wind"][t], pr["solar"][t])
        est = []
        for rep in range(6):
            r0 = np.random.default_rng(1000 * rep + t)
            inits = r0.choice(p.S["NL"], N, p=c["pi"][t]); seeds = r0.integers(0, 2**31, N)
            est.append(np.mean([p.cascade(P, c["lim"][t], i, np.random.default_rng(s), c["alive0"][t])[0] for i, s in zip(inits, seeds)]))
        est = np.array(est)
        if est.mean() > 0: rel.append(est.std() / est.mean())
    rows.append(dict(samples=N, rel_std_error=np.mean(rel)))
    print(f"(a) N={N}: mean relative std error {np.mean(rel):.3f}", flush=True)
pd.DataFrame(rows).to_csv(f"{CASE}_conv_mc.csv", index=False)

# ---------- (b) + (c) via the evaluation module ----------
sys.argv = ["evaluate.py", CASE]
import evaluate as e
Xtr_rows = e.tr
Xr = e.X[2015]
def stack(rows):
    return (np.vstack([np.c_[Xr[rows], np.tile(e.ENC[o], (rows.sum(), 1))] for o in range(e.NO)]),
            np.concatenate([np.log1p(e.Y[2015][rows, o]) for o in range(e.NO)]))
Xa, ya = stack(e.tr); Xb, yb = stack(e.va)
m = e.mdl().set_params(n_estimators=1200)
m.fit(Xa, ya, eval_set=[(Xa, ya), (Xb, yb)], eval_metric="l2")
ev = m.evals_result_
curve = pd.DataFrame(dict(iteration=np.arange(1, 1201), train_l2=ev["training"]["l2"], valid_l2=ev["valid_1"]["l2"]))
curve.to_csv(f"{CASE}_conv_lgbm.csv", index=False)
print("(b) valid l2 at 100/300/600/1200 iters:", [round(curve.valid_l2[i - 1], 4) for i in (100, 300, 600, 1200)])

H15 = np.array(e.H[2015]); rows = []
for months in [1, 2, 4, 8, 12]:
    use = H15 < months * 730
    mm = e.df_fit(use); pdf = e.df_pred(mm, e.X[2016])
    ch = np.argmin(e.COST[2016] + e.LAM * pdf, 1)
    tot = e.outcome(2016, np.ones(len(e.H[2016]), bool), ch).sum() / 1e3
    rows.append(dict(train_months=months, total_GWh=tot, vs_no_action_pct=100 * (1 - tot * 1e3 / e.res["No action"].sum())))
    print(f"(c) {months} months: total {tot:.1f} GWh", flush=True)
pd.DataFrame(rows).to_csv(f"{CASE}_conv_trainsize.csv", index=False)
