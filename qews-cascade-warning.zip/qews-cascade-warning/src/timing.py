"""Table IV: training time, per-hour feature/decision time, and Monte Carlo time for all 13 options.
Usage: python ../src/timing.py case118   (add 2500 for case300)"""
import sys, time, io, contextlib, pickle, numpy as np
case = sys.argv[1]; nh = sys.argv[2] if len(sys.argv) > 2 else "0"
sys.argv = ["evaluate.py", case, nh]
with contextlib.redirect_stdout(io.StringIO()):
    import evaluate as e
import pipeline as p
t0 = time.perf_counter(); m = e.df_fit(np.ones(len(e.H[2015]), bool)); tr = time.perf_counter() - t0
hrs = e.H[2016][:200]; t0 = time.perf_counter()
for t in hrs: p.feat_hour((2016, t))
tf = (time.perf_counter() - t0) / len(hrs)
t0 = time.perf_counter(); e.df_pred(m, e.X[2016][:200]); ti = (time.perf_counter() - t0) / 200
D = pickle.load(open(f"{case}_gt2.pkl", "rb"))["GT"]
risky = [t for (y, t), v in D.items() if y == 2016 and v[0][0] > 0][:15]
t0 = time.perf_counter(); [p.gt_hour((2016, t)) for t in risky]; tmc = (time.perf_counter() - t0) / len(risky)
print(f"{case}: training {tr:.1f} s | features {1e3*tf:.1f} ms/h | decision {1e3*ti:.2f} ms/h | "
      f"simulating 13 options {tmc:.2f} s/h | speed-up {tmc/(tf+ti):.0f}x")
