"""Step 0: extract IEEE 39/118/300-bus data (MATPOWER cases via pandapower) into data/case*.pkl."""
import os, pickle, warnings
import numpy as np
import pandapower as pp, pandapower.networks as pn
warnings.filterwarnings("ignore")
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
for name, fn in [("case39", pn.case39), ("case118", pn.case118), ("case300", pn.case300)]:
    net = fn(); pp.rundcpp(net); ppc = net._ppc
    br, bus, gen = ppc["branch"], ppc["bus"], ppc["gen"]
    on = br[:, 10].real > 0
    d = dict(f=br[on, 0].real.astype(int), t=br[on, 1].real.astype(int), x=br[on, 3].real, pd=bus[:, 2].real,
             gbus=gen[:, 0].real.astype(int), pmax=gen[:, 8].real, gstat=gen[:, 7].real)
    pickle.dump(d, open(os.path.join(OUT, f"{name}.pkl"), "wb"))
    print(f"{name}: {len(d['pd'])} buses, {len(d['f'])} branches, {len(d['gbus'])} generators, load {d['pd'].sum():.0f} MW")
