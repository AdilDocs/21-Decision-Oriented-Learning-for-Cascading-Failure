"""Fig. 1: framework of the proposed decision-oriented early-warning and preventive-shedding method (PNG)."""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

INK, INK2, BLUE, LBLUE, GRAY, LGRAY, ORANGE = "#0b0b0b", "#52514e", "#2a78d6", "#e3eefb", "#9b9a96", "#f1f0ec", "#eb6834"
plt.rcParams.update({"font.family": "serif", "font.size": 7.2})
fig, ax = plt.subplots(figsize=(7.16, 2.75)); ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis("off")

def box(x, y, w, h, title, body, fc=LGRAY, ec=GRAY, tc=INK, bold=True):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=1.0", fc=fc, ec=ec, lw=0.9))
    ax.text(x + w / 2, y + h - 1.6, title, ha="center", va="top", fontsize=6.5, color=tc, fontweight="bold" if bold else "normal")
    ax.text(x + w / 2, y + h - (7.6 if "\n" in title else 4.8), body, ha="center", va="top", fontsize=5.7, color=INK2, linespacing=1.3)

def arrow(x0, y0, x1, y1, color=INK2, style="-|>", ls="-"):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle=style, mutation_scale=8, color=color, lw=0.9, ls=ls,
                                 shrinkA=0, shrinkB=0))

# ---- online (day-ahead) chain ----
ax.text(0.3, 39.6, "Day-ahead (online)", fontsize=7, color=BLUE, fontweight="bold", va="top")
box(0.3, 19, 17.5, 17.5, "Day-ahead inputs", "area load forecasts\nwind/solar forecasts\nweather indices\nmaintenance plan")
box(20.6, 19, 18, 17.5, "Physics layer", "DC power flow on\nplanned topology\nLODF N$-$1 screening\nderated line limits")
box(41.4, 19, 17.5, 17.5, "Features $\\mathbf{x}(t)$", "base-case loadings\nN$-$1 loadings\nweather exposure\nforecast quantities")
box(61.7, 19, 18.5, 17.5, "Action-conditioned\nlearner $\\hat g$", "predicts blackout\n$\\widehat{EL}_o(t)$ for each\nof 13 options", fc=LBLUE, ec=BLUE)
box(83, 27.5, 16.7, 9, "Early warning", "$\\widehat{EL}_0(t)$: risk\nwithout action", fc=LBLUE, ec=BLUE)
box(83, 13, 16.7, 12, "Shedding decision", "minimise $C_o+\\lambda\\widehat{EL}_o$\nover options: area and\namount, or no action", fc=LBLUE, ec=BLUE)
for x0, x1 in [(17.8, 20.6), (38.6, 41.4), (58.9, 61.7)]:
    arrow(x0 + 0.35, 27.7, x1 - 0.35, 27.7)
arrow(80.5, 31.5, 82.7, 31.5); arrow(80.5, 23, 82.7, 20)

# ---- offline chain ----
ax.text(0.3, 13.2, "Offline (training year)", fontsize=7, color=ORANGE, fontweight="bold", va="top")
box(0.3, 0.6, 27, 10, "Cascade simulator", "storm-driven outages and islanding\ngive labels $EL_o(t)$ for each option", fc="#fdf0ea", ec=ORANGE)
box(30.3, 0.6, 22, 10, "Training (Jan.$-$Aug.)", "regress $\\log(1+EL_o)$\non $[\\mathbf{x}(t),\\mathbf{e}_o]$", fc="#fdf0ea", ec=ORANGE)
box(55.3, 0.6, 24.9, 10, "Validation (Sep.$-$Dec.)", "tune $\\lambda$ on the realised\ncost $C_{o^*}+EL_{o^*}$", fc="#fdf0ea", ec=ORANGE)
arrow(27.6, 5.6, 30.0, 5.6, color=ORANGE); arrow(52.6, 5.6, 55.0, 5.6, color=ORANGE)
arrow(41.3, 10.9, 66, 18.7, color=ORANGE, ls="--"); arrow(80.5, 5.6, 89, 12.7, color=ORANGE, ls="--")
import os
out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "paper_figures", "fig1_framework.png")
fig.savefig(out, dpi=300, bbox_inches="tight")
