"""Fig. 4(b): relative error of the ANNUAL total of the Monte Carlo ground truth vs. samples per hour (IEEE 118-bus).
40 random risky training hours x 8 independent repetitions; annual error = sqrt(mean var * n_risky) / (mean * n_risky)."""
import sys, pickle, numpy as np, pandas as pd
sys.argv = ["pipeline.py", "case118"]
import pipeline as p, gridN as g
D = pickle.load(open("case118_gt2.pkl", "rb"))
risky = [t for t in range(8760) if D["GT"][(2015, t)][0][0] > 0]
hrs = np.random.default_rng(5).choice(risky, 40, replace=False); rows = []
for N in [10, 30, 60]:
    mus, vs = [], []
    for t in hrs:
        pr, c = p.PR[2015], p.C[2015]; P, _ = g.injections(pr["load"][t], pr["wind"][t], pr["solar"][t]); est = []
        for rep in range(8):
            r0 = np.random.default_rng(777 * rep + t); inits = r0.choice(p.S["NL"], N, p=c["pi"][t]); sd = r0.integers(0, 2**31, N)
            est.append(c["Lam"][t] * np.mean([p.cascade(P, c["lim"][t], i, np.random.default_rng(s), c["alive0"][t])[0] for i, s in zip(inits, sd)]))
        mus.append(np.mean(est)); vs.append(np.var(est, ddof=1))
    mus, vs = np.array(mus), np.array(vs); nr = len(risky)
    rows.append(dict(samples=N, annual_rel_error_pct=100 * np.sqrt(vs.mean() * nr) / (mus.mean() * nr)))
    print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv("case118_conv_mc_annual.csv", index=False)
