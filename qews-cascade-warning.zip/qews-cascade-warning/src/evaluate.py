"""Comparative study with AREA-TARGETED preventive shedding.  usage: python evaluate.py case118 [NH]
Protocol: models trained Jan-Aug 2015, all thresholds / lambda tuned on Sep-Dec 2015, retrained on 2015, tested once on 2016.
Alarm baselines shed in the area holding the most loaded N-1 line; their alarm rate and shedding amount are tuned on validation.
"""
import sys, pickle, numpy as np, pandas as pd, lightgbm as lgb, warnings
from sklearn.metrics import roc_auc_score
from scipy.stats import spearmanr
warnings.filterwarnings("ignore")
CASE = sys.argv[1]; NH = sys.argv[2] if len(sys.argv) > 2 else "0"
sys.argv = ["pipeline.py", CASE, NH]  # pipeline reads CASE / NH from argv
import pipeline as p
S, OPT, YRS = p.S, p.OPTIONS, p.YEARS; NO = len(OPT)
import os
TAG = os.environ.get("TAG", ""); FERR = float(os.environ.get("FERR", "0"))
GTAG = os.environ.get("GTAG", TAG)   # ground truth may be shared (forecast-error runs change only features)
D = pickle.load(open(f"{CASE}{GTAG}_gt2.pkl", "rb")); FT = pickle.load(open(f"{CASE}{TAG}_feat2.pkl", "rb"))
H = {y: [int(t) for t in p.HOURS[y]] for y in YRS}
X = {y: np.array([FT[(y, t)]["x"] for t in H[y]]) for y in YRS}

Y = {y: np.array([[D["GT"][(y, t)][i][0] for i in range(NO)] for t in H[y]]) for y in YRS}
AREAL = {y: np.array([[p.PR[y]["load_f"][t][S["BUS_AREA"] == a] @ np.maximum(S["PD0"][S["BUS_AREA"] == a], 0)
                       for a in range(4)] for t in H[y]]) for y in YRS}
COST = {y: np.stack([np.zeros(len(H[y])) if a < 0 else f * AREAL[y][:, a] for a, f in OPT], 1) for y in YRS}
AMAX = {y: np.array([FT[(y, t)]["amax"] for t in H[y]]) for y in YRS}
BASE = {y: np.array([FT[(y, t)]["base"] for t in H[y]]) for y in YRS}
ENC = np.array([[*(np.eye(4)[a] if a >= 0 else np.zeros(4)), f] for a, f in OPT])
mdl = lambda: lgb.LGBMRegressor(n_estimators=600, learning_rate=0.03, num_leaves=31, subsample=0.8, subsample_freq=1,
                                colsample_bytree=0.8, verbose=-1, random_state=0, deterministic=True, force_row_wise=True, n_jobs=2)

# interaction graph [ref11]
def learn_M(recs, nl):
    N = np.zeros((nl, nl)); cnt = np.zeros(nl)
    for gens in recs:
        for a, b in zip(gens[:-1], gens[1:]):
            for i in a:
                cnt[i] += 1
                for j in b: N[i, j] += 1.0 / len(a)
        for i in gens[-1]: cnt[i] += 1
    M = N / np.maximum(cnt, 1)[:, None]; r = np.max(np.abs(np.linalg.eigvals(M)))
    return M * (0.98 / r) if r >= 0.98 else M
DOWN = np.linalg.solve(np.eye(S["NL"]) - learn_M(D["RECS"], S["NL"]), np.ones(S["NL"]))
IG = {y: np.array([FT[(y, t)]["Lam"] * (FT[(y, t)]["m1"] @ DOWN) for t in H[y]]) for y in YRS}
# epidemic model on the line graph [ref12]
Al = np.zeros((S["NL"], S["NL"]))
for l in range(S["NL"]):
    Al[l] = (S["F"] == S["F"][l]) | (S["F"] == S["T"][l]) | (S["T"] == S["F"][l]) | (S["T"] == S["T"][l])
np.fill_diagonal(Al, 0)
def epidemic(base, beta=0.05, steps=3):
    out = []
    for i in range(0, len(base), 300):
        pr = 1 / (1 + np.exp(-(base[i:i + 300] - 0.85) / 0.05))
        for _ in range(steps):
            pr = 1 - (1 - pr) * np.prod(1 - beta * Al[None] * pr[:, None, :], axis=2)
        out.append(pr.sum(1))
    return np.concatenate(out)
EPI = {y: epidemic(BASE[y]) for y in YRS}

tr = np.array([t < 5832 for t in H[2015]]); va = ~tr; all15 = np.ones(len(H[2015]), bool)
def outcome(y, mask, ch):
    i = np.arange(mask.sum()); return COST[y][mask][i, ch] + Y[y][mask][i, ch]
def df_fit(rows):
    Xr = X[2015][rows]
    Xtr = np.vstack([np.c_[Xr, np.tile(ENC[o], (len(Xr), 1))] for o in range(NO)])
    ytr = np.concatenate([np.log1p(Y[2015][rows, o]) for o in range(NO)])
    return mdl().fit(Xtr, ytr)
def df_pred(m, Xs):
    return np.stack([np.expm1(m.predict(np.c_[Xs, np.tile(ENC[o], (len(Xs), 1))])) for o in range(NO)], 1).clip(0)
opt_idx = {(a, f): i for i, (a, f) in enumerate(OPT)}
def alarm_choice(score, tau, f, amax):
    area = np.argmax(amax, 1)
    return np.where(score > tau, np.array([opt_idx[(a, f)] for a in area]), 0)

ml = lambda rows: mdl().fit(X[2015][rows], np.log1p(Y[2015][rows, 0]))
SC = {"N-1 screening [ref5]": (X[2015][va, 20], X[2016][:, 20]),
      "Near-overload warning [ref28]": (X[2015][va, 19], X[2016][:, 19]),
      "Epidemic model [ref12]": (EPI[2015][va], EPI[2016]),
      "Interaction graph [ref11]": (IG[2015][va], IG[2016]),
      "ML predict-then-threshold [Pani25, Noebels21]": (ml(tr).predict(X[2015][va]), ml(all15).predict(X[2016]))}
n = len(H[2016]); all16 = np.ones(n, bool)
res, info = {"No action": outcome(2016, all16, np.zeros(n, int))}, {}
CHB = {}
for k, (s15, s16) in SC.items():
    best = None
    for r in [0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5]:
        tau = np.quantile(s15, 1 - r)
        for f in (0.02, 0.04, 0.08):
            v = outcome(2015, va, alarm_choice(s15, tau, f, AMAX[2015][va])).sum()
            if best is None or v < best[0]: best = (v, tau, f, r)
    _, tau, f, r = best
    CHB[k] = alarm_choice(s16, tau, f, AMAX[2016]); res[k] = outcome(2016, all16, CHB[k]); info[k] = f"top {r:.0%} hrs, {f:.0%} in riskiest area"
pva = df_pred(df_fit(tr), X[2015][va])
lams = [0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0, 12.0, 16.0, 24.0]
vals = [outcome(2015, va, np.argmin(COST[2015][va] + l * pva, 1)).sum() for l in lams]
LAM = lams[int(np.argmin(vals))]
MFULL = df_fit(all15); PDF = df_pred(MFULL, X[2016])
CH = np.argmin(COST[2016] + LAM * PDF, 1)
res["PROPOSED decision-focused"] = outcome(2016, all16, CH); info["PROPOSED decision-focused"] = f"lambda={LAM}"
res["Oracle (perfect knowledge)"] = outcome(2016, all16, np.argmin(COST[2016] + Y[2016], 1))

ev = Y[2016][:, 0] >= np.quantile(Y[2016][:, 0], 0.95)
warn = {k: v[1] for k, v in SC.items()}; warn["PROPOSED (predicted blackout)"] = PDF[:, 0]
W = pd.DataFrame([dict(Method=k, AUC=roc_auc_score(ev, v), Rank_corr=spearmanr(v, Y[2016][:, 0])[0]) for k, v in warn.items()])
scale = 8760 / n
B = pd.DataFrame([dict(Method=k, Total_GWh=v.sum() * scale / 1e3, setting=info.get(k, "")) for k, v in res.items()])
best_base = min(SC, key=lambda k: res[k].sum())
rng = np.random.default_rng(0); full = NH == "0"; blocks = n // 24 if full else n; bt = []
for _ in range(2000):
    h = (rng.integers(0, blocks, blocks)[:, None] * 24 + np.arange(24)).ravel() if full else rng.integers(0, n, n)
    bt.append(1 - res["PROPOSED decision-focused"][h].sum() / res[best_base][h].sum())
G = pd.DataFrame([dict(vs=best_base, gain_pct=100 * (1 - res["PROPOSED decision-focused"].sum() / res[best_base].sum()),
                       ci_lo=100 * np.percentile(bt, 2.5), ci_hi=100 * np.percentile(bt, 97.5),
                       vs_no_action_pct=100 * (1 - res["PROPOSED decision-focused"].sum() / res["No action"].sum()),
                       hours_acted=int((CH > 0).sum()))])
print(f"===== {CASE}: {n} test hours | no-action blackout = {100*Y[2016][:,0].sum()/AREAL[2016].sum():.2f}% of energy =====")
print(W.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
print(B.to_string(index=False, float_format=lambda x: f"{x:.2f}"))
print(G.to_string(index=False, float_format=lambda x: f"{x:.1f}"))
SUF = f"{TAG}_ferr{FERR}" if (TAG or FERR) else ""
for nm, df_ in [("warning", W), ("shedding", B), ("gain", G)]: df_.to_csv(f"{CASE}{SUF}_{nm}2.csv", index=False)
pickle.dump(dict(PDF=PDF, Y16=Y[2016], COST16=COST[2016], LAM=LAM, lams=lams, vals=vals, CH=CH, CHB=CHB, AREAL16=AREAL[2016], imp=MFULL.booster_.feature_importance(importance_type="gain")), open(f"{CASE}{SUF if (TAG or FERR) else ''}_eval2.pkl", "wb"))
