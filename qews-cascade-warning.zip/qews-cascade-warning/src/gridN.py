"""Generic DC grid model for IEEE 39/118/300 (same methodology for every system).
Set the system with  gridN.load_case("case118")  before use.
  * areas  : 4 modularity communities, each driven by one German TSO's OPSD load profile
  * RES    : wind at 3 buses of the two northern areas, solar at 3 buses of the two southern areas
  * dispatch: generators share net load in proportion to Pmax (distributed slack)
  * fast N-1 via LODF (radial branches excluded as initiators)
"""
import numpy as np, pickle, pandas as pd, networkx as nx
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from networkx.algorithms.community import greedy_modularity_communities

import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV = os.environ.get("OPSD_CSV", os.path.join(ROOT, "data", "time_series_60min_singleindex.csv"))
CASE_DIR = os.path.join(ROOT, "data")
AREAS = ["50hertz", "tennet", "amprion", "transnetbw"]          # north ... south
S = {}                                                         # system state (filled by load_case)


def load_case(name, wind_share=0.18, solar_share=0.12):
    d = pickle.load(open(os.path.join(CASE_DIR, f"{name}.pkl"), "rb"))
    nb, nl = len(d["pd"]), len(d["f"])
    pmax = d["pmax"].copy(); pmax[pmax >= 5000] = 300.0                     # condensers / slack placeholders
    pmax[d["gstat"] <= 0] = 0
    x = np.where(np.abs(d["x"]) < 1e-4, 1e-4, d["x"])
    G = nx.Graph(); G.add_nodes_from(range(nb)); G.add_edges_from(zip(d["f"], d["t"]))
    comms = sorted([sorted(c) for c in greedy_modularity_communities(G, cutoff=4, best_n=4)], key=lambda c: min(c))
    bus_area = np.zeros(nb, int)
    for a, c in enumerate(comms): bus_area[c] = a
    bridges = [l for l in range(nl) if _is_bridge(d["f"], d["t"], nb, l)]
    pd0 = d["pd"].copy(); tot = pd0[pd0 > 0].sum()
    rng = np.random.default_rng(1)
    loadbus = lambda areas: [b for b in range(nb) if bus_area[b] in areas and pd0[b] > 0]
    wind_bus = list(rng.choice(loadbus([0, 1]), 3, replace=False))
    solar_bus = list(rng.choice(loadbus([2, 3]), 3, replace=False))
    S.update(name=name, NB=nb, NL=nl, F=d["f"], T=d["t"], X=x, PD0=pd0, GBUS=d["gbus"], PMAX=pmax,
             BUS_AREA=bus_area, BRIDGES=bridges, INIT=np.array([l for l in range(nl) if l not in bridges]),
             WIND_BUS=wind_bus, SOLAR_BUS=solar_bus, WIND_CAP=wind_share * tot, SOLAR_CAP=solar_share * tot,
             WIND_SRC=[AREAS[bus_area[b]] if AREAS[bus_area[b]] in ("50hertz", "tennet") else "tennet" for b in wind_bus],
             SOLAR_SRC=[AREAS[bus_area[b]] for b in solar_bus])
    A = np.zeros((nl, nb)); A[np.arange(nl), d["f"]] = 1; A[np.arange(nl), d["t"]] = -1
    S["A"] = A
    peak = 1.2 * 1.0 / 0.85 * 0.85 * pd0[pd0 > 0].sum() * 1.25          # ~ peak residual load with margin
    if S["PMAX"].sum() < peak:
        S["PMAX"] = S["PMAX"] * peak / S["PMAX"].sum()
    return S


def _is_bridge(f, t, nb, l):
    m = np.ones(len(f), bool); m[l] = False
    g = csr_matrix((np.ones(m.sum()), (f[m], t[m])), shape=(nb, nb))
    return connected_components(g, directed=False)[0] > 1


def profiles(year):
    allc = pd.read_csv(CSV, nrows=0).columns
    want = ["utc_timestamp"] + [c for c in allc if any(c.startswith(f"DE_{a}_") for a in AREAS) and
            ("load_" in c or "solar_generation_actual" in c or c.endswith("wind_generation_actual")
             or c.endswith("wind_onshore_generation_actual"))]
    df = pd.read_csv(CSV, usecols=want); df = df[df.utc_timestamp.str.startswith(str(year))].copy()
    num = df.columns[1:]; df[num] = df[num].interpolate().bfill().ffill()
    T, nb = len(df), S["NB"]; L = np.zeros((T, nb)); Lf = np.zeros((T, nb))
    for a, name in enumerate(AREAS):
        la = df[f"DE_{name}_load_actual_entsoe_transparency"].values
        lf = df[f"DE_{name}_load_forecast_entsoe_transparency"].values
        ref = la.mean() / 0.85
        L[:, S["BUS_AREA"] == a] = (la / ref)[:, None]; Lf[:, S["BUS_AREA"] == a] = (lf / ref)[:, None]
    def cf(name, kind):
        col = f"DE_{name}_{kind}_generation_actual"
        if col not in df: col = f"DE_{name}_wind_onshore_generation_actual"
        v = df[col].values; return np.clip(v / np.quantile(v, 0.999), 0, 1)
    W = np.stack([cf(a, "wind") for a in AREAS], 1); Sol = np.stack([cf(a, "solar") for a in AREAS], 1)
    return dict(load=L, load_f=Lf, wind=np.stack([cf(n, "wind") for n in S["WIND_SRC"]], 1),
                solar=np.stack([cf(n, "solar") for n in S["SOLAR_SRC"]], 1), W=W, S=Sol,
                sys=L @ np.maximum(S["PD0"], 0) / np.maximum(S["PD0"], 0).sum())


def injections(load_scale, wind_cf, solar_cf, shed=None):
    pd_ = S["PD0"] * load_scale
    if shed is not None: pd_ = pd_ - shed
    res = np.zeros(S["NB"])
    res[S["WIND_BUS"]] += S["WIND_CAP"] / 3 * np.asarray(wind_cf)
    res[S["SOLAR_BUS"]] += S["SOLAR_CAP"] / 3 * np.asarray(solar_cf)
    net = pd_.sum() - res.sum()
    pg = np.zeros(S["NB"]); np.add.at(pg, S["GBUS"], S["PMAX"] / S["PMAX"].sum() * net)
    return pg + res - pd_, pd_


def ptdf(alive):
    """PTDF for a connected topology (slack = first generator bus)."""
    b = alive / S["X"]; A = S["A"]
    Bbus = A.T @ (b[:, None] * A); ref = S["GBUS"][0]; o = np.r_[0:ref, ref + 1:S["NB"]]
    Binv = np.zeros((S["NB"], S["NB"])); Binv[np.ix_(o, o)] = np.linalg.inv(Bbus[np.ix_(o, o)])
    return (b[:, None] * A) @ Binv


def lodf_n1(P, alive, ptd=None):
    """Post-contingency flows F1[k,l] for every initiator k (LODF), base flows f0."""
    H = ptdf(alive) if ptd is None else ptd
    f0 = H @ P
    Hl = H @ S["A"].T                                           # (NL, NL): flow on l per unit transfer on k's ends
    denom = 1 - np.diag(Hl)
    K = S["INIT"]
    lodf = Hl[:, K] / np.where(np.abs(denom[K]) < 1e-9, np.nan, denom[K])[None, :]
    F1 = (f0[:, None] + lodf * f0[K][None, :]).T                 # (len(K), NL)
    F1[np.arange(len(K)), K] = 0
    F1[:, alive == 0] = 0
    return np.nan_to_num(F1), f0


def dcflow(P, alive):
    """Full DC flow with islanding; returns flows and load lost."""
    nb, nl = S["NB"], S["NL"]; F, T = S["F"], S["T"]
    on = alive > 0
    ncomp, lab = connected_components(csr_matrix((np.ones(on.sum()), (F[on], T[on])), shape=(nb, nb)), directed=False)
    b = alive / S["X"]; A = S["A"]; Bbus = A.T @ (b[:, None] * A)
    theta = np.zeros(nb); lost = 0.0; P = P.copy()
    gcap = np.zeros(nb); np.add.at(gcap, S["GBUS"], S["PMAX"])
    for c in range(ncomp):
        idx = np.where(lab == c)[0]
        gens = idx[gcap[idx] > 0]; loadc = -np.minimum(P[idx], 0).sum(); imb = P[idx].sum()
        if len(gens) == 0:
            lost += loadc; P[idx] = 0; continue
        if imb < 0:
            head = np.clip(gcap[gens] - np.maximum(P[gens], 0), 0, None); up = min(-imb, head.sum())
            if head.sum() > 0: P[gens] += head / head.sum() * up
            short = -imb - up
            if short > 0:
                ld = idx[P[idx] < 0]; P[ld] *= 1 - short / (-P[ld].sum()); lost += short
        else:
            pos = np.maximum(P[gens], 0); P[gens] -= imb * pos / max(pos.sum(), 1e-9)
        if len(idx) > 1:
            ref = gens[0]; o = idx[idx != ref]
            theta[o] = np.linalg.solve(Bbus[np.ix_(o, o)], P[o])
    return (b[:, None] * A) @ theta, lost


def trip_prob(r):
    return np.clip((r - 0.95) / 0.25, 0, 1) ** 2


def make_limits(pr, q=0.6, k=1.05, nsamp=60):
    rng = np.random.default_rng(0); alive = np.ones(S["NL"])
    hrs = rng.choice(np.where(pr["sys"] <= np.quantile(pr["sys"], q))[0], nsamp, replace=False)
    H = ptdf(alive); worst = np.zeros(S["NL"])
    for t in hrs:
        P, _ = injections(pr["load"][t], pr["wind"][t], pr["solar"][t])
        F1, f0 = lodf_n1(P, alive, H)
        worst = np.maximum(worst, np.maximum(np.abs(f0), np.abs(F1).max(0)))
    return np.maximum(k * worst, 0.02 * np.abs(S["PD0"]).sum() / 10)
