"""Table V and Section V-D: characteristics of shedding decisions (proposed vs. best benchmark) and feature importance."""
import pickle, numpy as np, pandas as pd
OPT = [(-1, 0.0)] + [(a, f) for a in range(4) for f in (0.02, 0.04, 0.08)]
rows = []
for c in ["case39", "case118", "case300"]:
    e = pickle.load(open(f"{c}_eval2.pkl", "rb")); Y, C = e["Y16"], e["COST16"]; n = len(Y); i = np.arange(n)
    best = pd.read_csv(f"{c}_gain2.csv").iloc[0].vs; sev = Y[:, 0] >= np.quantile(Y[:, 0], 0.95)
    for name, ch in [("Proposed", e["CH"]), (best, e["CHB"][best])]:
        act = ch > 0; shed = C[i, ch].sum(); avoided = (Y[:, 0] - Y[i, ch]).sum(); f = np.array([OPT[o][1] for o in ch])
        rows.append(dict(system=c, method=name, hours_acted_pct=100 * act.mean(), severe_hours_acted_pct=100 * act[sev].mean(),
                         zero_risk_actions_pct=100 * (act & (Y[:, 0] == 0)).sum() / max(act.sum(), 1),
                         loss_avoided_per_MWh_shed=avoided / max(shed, 1e-9), share_2pct_actions=100 * np.mean(f[act] == 0.02) if act.any() else 0,
                         median_pred_loss_8pct_MW=np.median(e["PDF"][f == 0.08, 0]) if (f == 0.08).any() else np.nan,
                         median_pred_loss_2pct_MW=np.median(e["PDF"][f == 0.02, 0]) if (f == 0.02).any() else np.nan))
    a1, a2 = e["CH"] > 0, e["CHB"][best] > 0; both = a1 & a2
    same = np.mean([OPT[x][0] == OPT[y][0] for x, y in zip(e["CH"][both], e["CHB"][best][both])]) if both.any() else np.nan
    imp = e["imp"]; NL = (len(imp) - 30) // 2
    grp = dict(load=range(0, 4), res=range(4, 10), weather=range(10, 18), maint=[18], base=[19] + list(range(21, 21 + NL)),
               n1=[20] + list(range(21 + NL, 25 + 2 * NL)), option=range(25 + 2 * NL, 30 + 2 * NL))
    print(c, "| same area when both act: %.0f%%" % (100 * same), "| importance %:",
          {k: round(100 * imp[list(v)].sum() / imp.sum(), 1) for k, v in grp.items()})
T = pd.DataFrame(rows); T.to_csv("results/table_decisions.csv", index=False); print(T.round(2).to_string(index=False))
