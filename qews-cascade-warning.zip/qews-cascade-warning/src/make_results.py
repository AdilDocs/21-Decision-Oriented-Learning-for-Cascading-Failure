"""Compile all experiment outputs into tables + publication figures (results/)."""
import os, glob, pickle, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
os.chdir(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "work")); os.makedirs("results", exist_ok=True)

BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
GRAY, LGRAY, INK, INK2 = "#9b9a96", "#d6d5d0", "#0b0b0b", "#52514e"
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.color": "#e6e5e1", "grid.linewidth": 0.5,
                     "axes.axisbelow": True, "savefig.dpi": 300, "savefig.bbox": "tight"})
SYS = [("case39", "IEEE 39-bus"), ("case118", "IEEE 118-bus"), ("case300", "IEEE 300-bus")]
SHORT = {"N-1 screening [ref5]": "N-1 screening", "Near-overload warning [ref28]": "Near-overload warning",
         "Epidemic model [ref12]": "Epidemic model", "Interaction graph [ref11]": "Interaction graph",
         "ML predict-then-threshold [Pani25, Noebels21]": "ML predict-then-threshold",
         "PROPOSED decision-focused": "Proposed (decision-focused)", "Oracle (perfect knowledge)": "Oracle (perfect knowledge)",
         "No action": "No action", "PROPOSED (predicted blackout)": "Proposed"}

# ---------------- Table 1: main comparison ----------------
rows = []
for c, name in SYS:
    B = pd.read_csv(f"{c}_shedding2.csv"); W = pd.read_csv(f"{c}_warning2.csv"); G = pd.read_csv(f"{c}_gain2.csv").iloc[0]
    none = B.loc[B.Method == "No action", "Total_GWh"].iloc[0]
    for _, r in B.iterrows():
        w = W[W.Method == r.Method] if r.Method in set(W.Method) else W[W.Method == "PROPOSED (predicted blackout)"] if r.Method.startswith("PROPOSED") else None
        rows.append(dict(System=name, Method=SHORT[r.Method], Total_GWh=round(r.Total_GWh, 1),
                         Change_vs_no_action_pct=round(100 * (r.Total_GWh / none - 1), 1),
                         AUC=round(w.AUC.iloc[0], 3) if w is not None and len(w) else None,
                         Rank_corr=round(w.Rank_corr.iloc[0], 3) if w is not None and len(w) else None,
                         Tuned_setting=r.setting if isinstance(r.setting, str) else ""))
    rows.append(dict(System=name, Method=f"Gain vs best baseline ({SHORT[G.vs]})",
                     Total_GWh=None, Change_vs_no_action_pct=None, AUC=None, Rank_corr=None,
                     Tuned_setting=f"{G.gain_pct:.1f}% [95% CI {G.ci_lo:.1f}, {G.ci_hi:.1f}]"))
T1 = pd.DataFrame(rows); T1.to_csv("results/table_main_comparison.csv", index=False)

# ---------------- Fig 1: comparison (total load interrupted relative to no action) ----------------
order = ["N-1 screening", "Near-overload warning", "Epidemic model", "Interaction graph", "ML predict-then-threshold",
         "Proposed (decision-focused)", "Oracle (perfect knowledge)"]
fig, axes = plt.subplots(1, 3, figsize=(7.16, 2.3), sharey=True)
for ax, (c, name) in zip(axes, SYS):
    d = T1[(T1.System == name) & T1.Method.isin(order)].set_index("Method").loc[order]
    vals = 100 + d.Change_vs_no_action_pct.values
    cols = [BLUE if m.startswith("Proposed") else (LGRAY if m.startswith("Oracle") else GRAY) for m in order]
    y = np.arange(len(order))[::-1]
    ax.barh(y, vals, color=cols, height=0.62, edgecolor="white", linewidth=1)
    ax.axvline(100, color=INK, lw=0.8, ls="--"); ax.text(100, -0.95, "no action", fontsize=6.5, color=INK2, ha="center", va="top")
    for yi, v, m in zip(y, vals, order):
        ax.text(max(v, 100) + 2 if abs(v - 100) < 12 else v + 2, yi, f"{v:.0f}%", va="center", fontsize=6.5, color=INK if m.startswith("Proposed") else INK2,
                fontweight="bold" if m.startswith("Proposed") else "normal")
    ax.set_title(name); ax.set_xlim(0, max(vals) + 22); ax.set_ylim(-1.6, len(order) - 0.4); ax.grid(axis="y", visible=False)
    ax.set_xlabel("Load interrupted (% of no action)")
axes[0].set_yticks(np.arange(len(order))[::-1]); axes[0].set_yticklabels(order)
fig.savefig("results/fig_comparison.png"); fig.savefig("results/fig_comparison.pdf"); plt.close(fig)

# ---------------- Table 2 + Fig 2: sensitivity (IEEE 39-bus, full data) ----------------
def gain(tag):
    f = "case39_gain2.csv" if tag == "base" else glob.glob(f"case39{tag}_ferr*_gain2.csv")[0]
    return pd.read_csv(f).iloc[0]
sens = []
for lab, val, tag in [("Storm intensity K", 0, "_full_K0"), ("Storm intensity K", 12.5, "_full_K12"),
                      ("Storm intensity K", 25, "base"), ("Storm intensity K", 50, "_full_K50"),
                      ("Maintenance probability", 0.0, "_full_M0"), ("Maintenance probability", 0.3, "_full_M3"),
                      ("Maintenance probability", 0.6, "base"), ("Maintenance probability", 0.9, "_full_M9"),
                      ("Extra forecast error", 0.0, "base"), ("Extra forecast error", 0.02, "_full_f0.02"),
                      ("Extra forecast error", 0.05, "_full_f0.05"), ("Extra forecast error", 0.10, "_full_f0.10")]:
    g = gain(tag)
    sens.append(dict(Factor=lab, Value=val, Gain_vs_best_baseline_pct=round(g.gain_pct, 1), CI_low=round(g.ci_lo, 1),
                     CI_high=round(g.ci_hi, 1), Best_baseline=SHORT[g.vs], Reduction_vs_no_action_pct=round(g.vs_no_action_pct, 1)))
T2 = pd.DataFrame(sens); T2.to_csv("results/table_sensitivity.csv", index=False)

lam_rows = []
for c, name in SYS:
    e = pickle.load(open(f"{c}_eval2.pkl", "rb"))
    v = np.array(e["vals"]); lam_rows.append((name, np.array(e["lams"]), v / v.min(), e["LAM"]))
fig, axes = plt.subplots(1, 4, figsize=(7.16, 1.9))
for ax, fac, xl in zip(axes[:3], ["Storm intensity K", "Maintenance probability", "Extra forecast error"],
                       ["Storm intensity $K$", "Maintenance prob.", "Forecast error"]):
    d = T2[T2.Factor == fac]
    x = d.Value.values * (100 if fac == "Extra forecast error" else 1)
    ax.errorbar(x, d.Gain_vs_best_baseline_pct, yerr=[d.Gain_vs_best_baseline_pct - d.CI_low, d.CI_high - d.Gain_vs_best_baseline_pct],
                color=BLUE, lw=2, marker="o", ms=4.5, mec="white", mew=0.8, capsize=2.5, elinewidth=0.9)
    ax.axhline(0, color=INK2, lw=0.7)
    ax.set_xlabel(xl + (" [%]" if fac == "Extra forecast error" else "")); ax.set_xticks(x); ax.set_xticklabels([f"{v:g}" for v in x])
    if fac == "Storm intensity K": ax.set_xticks([0, 12.5, 25, 50]); ax.set_xticklabels(["0", "12.5", "25", "50"], fontsize=6.5)
axes[0].set_ylabel("Gain vs best baseline [%]\n(95% CI)")
for (name, l, v, L), col, mk in zip(lam_rows, [BLUE, ORANGE, AQUA], ["o", "s", "^"]):
    axes[3].plot(l, v, color=col, lw=2, marker=mk, ms=4, mec="white", mew=0.6, label=name.replace("IEEE ", ""))
axes[3].set_xscale("log"); axes[3].set_xlabel(r"Risk weight $\lambda$"); axes[3].set_ylabel("Relative validation cost")
axes[3].legend(frameon=False, loc="lower left", bbox_to_anchor=(0, 1.02), ncol=3, handlelength=1.2, columnspacing=0.6, fontsize=6)
for ax, t in zip(axes, "abcd"): ax.set_title(f"({t})", loc="left", pad=14 if t == "d" else 4)
fig.tight_layout(w_pad=1.6); fig.savefig("results/fig_sensitivity.png"); fig.savefig("results/fig_sensitivity.pdf"); plt.close(fig)

# ---------------- Table 3 + Fig 3: convergence (IEEE 118-bus) ----------------
mc = pd.read_csv("case118_conv_mc.csv")
annual = pd.read_csv("case118_conv_mc_annual.csv")   # produced by conv_mc_annual.py
lg = pd.read_csv("case118_conv_lgbm.csv"); ts = pd.read_csv("case118_conv_trainsize.csv")
ts["total_GWh"] = ts.total_GWh * 8760 / 8784          # same annualisation (2016 has 8784 h) as the main tables
mc.to_csv("results/table_conv_mc_hourly.csv", index=False); annual.to_csv("results/table_conv_mc_annual.csv", index=False)
ts.to_csv("results/table_conv_trainsize.csv", index=False)
fig, axes = plt.subplots(1, 4, figsize=(7.16, 1.9))
axes[0].plot(mc.samples, mc.rel_std_error, color=BLUE, lw=2, marker="o", ms=4.5, mec="white", mew=0.8)
axes[0].set_xscale("log"); axes[0].set_xlabel("Outage samples per hour"); axes[0].set_ylabel("Hourly rel. error")
axes[1].plot(annual.samples, annual.annual_rel_error_pct, color=BLUE, lw=2, marker="o", ms=4.5, mec="white", mew=0.8)
axes[1].axvline(30, color=INK2, ls="--", lw=0.7); axes[1].text(31, annual.annual_rel_error_pct.max() * 0.9, "used: 30", fontsize=6.5, color=INK2)
axes[1].set_xlabel("Outage samples per hour"); axes[1].set_ylabel("Annual-total error [%]")
axes[2].plot(lg.iteration, lg.train_l2, color=BLUE, lw=1.5, label="training")
axes[2].plot(lg.iteration, lg.valid_l2, color=ORANGE, lw=1.5, label="validation")
axes[2].axvline(600, color=INK2, ls="--", lw=0.7); axes[2].legend(frameon=False)
axes[2].set_xlabel("Boosting iterations"); axes[2].set_ylabel("Loss (MSE)")
axes[3].plot(ts.train_months, ts.total_GWh, color=BLUE, lw=2, marker="o", ms=4.5, mec="white", mew=0.8)
none118 = T1[(T1.System == "IEEE 118-bus") & (T1.Method == "No action")].Total_GWh.iloc[0]
axes[3].axhline(none118, color=INK2, ls="--", lw=0.7); axes[3].text(1, none118 - 3, "no action", fontsize=6.5, color=INK2, va="top")
axes[3].set_xlabel("Training data [months]"); axes[3].set_ylabel("Load interrupted [GWh]")
axes[3].set_ylim(min(ts.total_GWh.min(), none118) * 0.9, none118 * 1.05)
for ax, t in zip(axes, "abcd"): ax.set_title(f"({t})", loc="left")
fig.tight_layout(w_pad=1.8); fig.savefig("results/fig_convergence.png"); fig.savefig("results/fig_convergence.pdf"); plt.close(fig)

pd.set_option("display.width", 220); pd.set_option("display.max_colwidth", 60)
print(T1.to_string(index=False)); print(); print(T2.to_string(index=False)); print(); print(ts.to_string(index=False))
